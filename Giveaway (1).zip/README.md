[![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/anonymouseJoke/giveaway) [![Run on Repl.it](https://repl.it/badge/github/anonymouseJoke/giveaway)](https://repl.it/github/anonymouseJoke/giveaway) [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/anonymouseJoke/giveaway)

# [Want One With Giveaway Requirements and Bonus Enteries?](https://github.com/anonymouseJoke)
- [Check Out (coming soon)](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

**This Giveaway bot was created by you and anonymouseJoke**

# [Select Language](https://nodejs.org/en/)
**Select Language Node.js**

# [Configure the run button](https://docs.npmjs.com/packages-and-modules/)
**npm start**

# [Easy set up!]()
# 1: Get Your bot token [here](https://discord.com/developers/applications)
# 2: Enable Privilleged gateway intents!
![Joke](https://user-images.githubusercontent.com/87341400/125494942-d4c347c3-905d-42a6-871b-6e8fadea7963.gif)
# 3: last step in config.json put your token there



# Run the Project
Glitch: Glitch: [![Remix on Glitch](https://cdn.glitch.com/2703baf2-b643-4da7-ab91-7ee2a2d00b5b%2Fremix-button.svg)](https://glitch.com/edit/#!/import/github/anonymouseJoke/giveaway)

Repl: [![Run on Repl.it](https://repl.it/badge/github/anonymouseJoke/giveaway)](https://repl.it/github/anonymouseJoke/giveaway)

heroku: [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/anonymouseJoke/giveaway)
