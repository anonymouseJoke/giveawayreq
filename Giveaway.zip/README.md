# [Want One With Giveaway Requirements and Bonus Enteries?](https://github.com/ZeroDiscord/Giveaway)
- [Check Out (coming soon)](https://www.youtube.com/watch?v=dQw4w9WgXcQ)

**This Giveaway bot was created by you**

**IN CONFIG.JSON DO NOT CHANGE ANY VARIABLE THE everyoneMention VARIABLE IS FOR THE EVERYONE MENTION WHEN A NEW GIVEAWAY OCCURS AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES 
INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!**

**also check invite.js and change the things what you have to change**
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/watch?v=dQw4w9WgXcQ)
- [Support Server Link](https://discord.gg/)
# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give your self credit

# GLITCH
**Read if your an glitch user**

**NOTE FOR GLITCH HOSTERS 
`` THIS BOT DIES IF YOU DON'T USE IT EVERY 5 MINUTES CAN BE EASILY RE-HOSTED BY REGENERATING THE TOKEN AND REPPLACING IT 

# Host On Repl.it
- [replit.com](https://replit.com/repls)